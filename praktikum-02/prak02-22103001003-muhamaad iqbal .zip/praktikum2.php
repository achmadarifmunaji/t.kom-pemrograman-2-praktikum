<?php

// Terapkan constructor pada class Fruit
class Fruit
{
    // data atau property
    public $name;
    public $color;
     //construktur 
    function __construct($name = "name", 
    $color = "color")
    {
        $this->name = $name;
        $this->color = $color;
    }

    function getData()
    {
        return "$this->name, $this->color";
    }

    function getAllData(){
        if ($this->shape1 > 0){
            return "{$this->name} | berwarna {$this->color} - 
            berbentuk {$this->shape1} <br/>";
        } elseif ($this->shape2 > 0){
            return "{$this->name} | berwarna {$this->color} -
             berbentuk {$this->shape2}";
        }
    }
}
    //detail
    class DetailFruit {
        function detail (Fruit $Fruit){
            return"I Love {$Fruit->name} and {$Fruit->color} </br>";
        }
}
 
class Apple extends fruit
{
    public $shape1;
    function __construct($name, $color, $shape2, $shape1 = "round"){
        parent::__construct($name, $color);
        $this->shape1 = $shape1;
    }
    function getData(){
        return parent::getData() . " - {$this->shape1}r <br/>";
    }
    function detailBuah1(){
        return "I love {$this->name} its {$this->color} its {$this->shape1} <br/>";
    }
}
class Banana extends fruit
{
    public $shape2;
    function __construct($name, $color, $shape1, $shape2 = "round"){
        parent::__construct($name, $color);
        $this->shape2 = $shape2;
    }
    function getData(){
        return parent::getData() . " - {$this->shape2} <br/>";
    }
    function detailBuah2(){
        return "I love {$this->name} its {$this->color} its {$this->shape2} <br/>";
    }
}

// instance object detail Fruit
$fruit1 = new Fruit("wine","purple",
 "malang", "round");
$detail2 = new DetailFruit();
//pemanggilan detail fruit
echo $detail2->detail($fruit1);

//data child Apple
$trans1 = new Apple("appel", 
"red", 0, "round");
//data child Banana
$trans2 = new Banana("banana", 
"yellow", 0, "long");
//pemanggilan child Apple 
echo $trans1->detailBuah1();
//pemanggilan child banana
echo $trans2->detailBuah2();


class Kalkulator
{
    // data atau property
    public $angka1;
    public $angka2;
     //construktur 
    function __construct($angka1 = 0, 
    $angka2 = 0)
    {
        $this->angka1 = $angka1;
        $this->angka2 = $angka2;
    }
}

class Tambah extends Kalkulator
{
    function Tambah(){
        return 
        "hasil dari 12 + 2 =" .
        $this->angka1 + $this->angka2;
    }
}
class Kurang extends Kalkulator
{
    function Kurang(){
        return
        "hasil dari 12 - 2 =" .
        $this->angka1 - $this->angka2;
    }
}
class Bagi extends Kalkulator
{
    function Bagi(){
        return 
        "hasil dari 12 : 2 =" .
        $this->angka1 / $this->angka2 ;
    }
}
//data child Tambah
$hasil1 = new Tambah(12,2);
//data child Kurang
$hasil2 = new Kurang(12,2);
//data child Bagi
$hasil3 = new Bagi(12,2);
//pemanggilan child Tambah
echo $hasil1->Tambah();
echo "<br>";
//pemanggilan child kurang
echo $hasil2->Kurang();
echo "<br>";
//pemanggilan child Bagi
echo $hasil3->Bagi();
echo "<br>";

