
<?php

class laptop{

   //property
   public $merek = "HP";
   public $ukuranLayar = "14 inci";
   public $harga = "Rp 6.000.000,-";
   public $tipe	= "AN004AU";
   public $prosesor	= "AMD Quad-Core"; 

   //method 
   public function berbagiFile(){
       return "bisa <br/>";
   }
   
   public function isiDayaBaterai(){
       return "bisa <br/>";
   }
   
    public function ketikLaporan(){
        return "bisa <br/>";
    }

    public function rekamVideo(){
        return "bisa <br/>";
    }
    
}

//instansiasi class laptop
$laptop1 = new laptop();

var_dump($laptop1);

//memanggil method berbagiFile dari class laptop
echo $laptop1->berbagiFile();

//method isiDayaBaterai dari class laptop
echo $laptop1->isiDayaBaterai();

//memanggil method ketikLaporan dari class laptop
echo $laptop1->ketikLaporan();

//method rekamVideo dari class laptop
echo $laptop1->rekamVideo();


class kalkulator{
       //property
    public $angka1 = "31";
    public $angka2 = "12"; 
   //method 
    public function tambahAngka(){
       return $this->angka1 + $this->angka2;
    }

    public function kurangAngka(){
        return $this->angka1 - $this->angka2;
    }
}

$hasil = new kalkulator();

var_dump($hasil);

//memanggil method tambahAngka dari class kalkulator
echo $hasil->tambahAngka();

//method kurangAngka dari class kalkulator
echo $hasil->kurangAngka();