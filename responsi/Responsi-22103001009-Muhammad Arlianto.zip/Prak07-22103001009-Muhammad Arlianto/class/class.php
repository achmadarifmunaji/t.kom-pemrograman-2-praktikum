<?php 
// require_once 'gambar/gambar.png';
class Blog
{
    public $nameBlog = "Blog Tugas Praktikum ke-6 Pemrograman II";
    public $penulis = "Li AN";
    public $tahun = 2023;
    public $bulan = "09";
    public $tanggal = 29;
    public $judul = "Praktikum ke-6 Pemrograman II";
    public $artikel1 = "HTML (Hypertext Markup Language) adalah singkatan dari Bahasa Pemformatan Hiperteks (HyperText Markup Language) dan merupakan bahasa standar yang digunakan untuk membuat halaman web. HTML digunakan untuk menentukan struktur dan tampilan visual dari konten sebuah halaman web, seperti teks, gambar, video, tabel, dan elemen-elemen lainnya.";
    public $artikel2 = "CSS (Cascading Style Sheets) adalah bahasa pemformatan yang digunakan untuk mengendalikan tampilan dan tata letak elemen-elemen dalam sebuah dokumen HTML. CSS memungkinkan pengguna untuk mengubah penampilan visual dari halaman web, termasuk warna, ukuran, jenis font, tata letak, dan elemen-elemen lainnya.";

    public function nameBlog()
    {
        return $this->nameBlog;
    }
    function tahun()
    {
        return $this->tahun;
    }
    function bulan()
    {
        return $this->bulan;
    }
    function tanggal()
    {
        return $this->tanggal;
    }
    function penulis()
    {
        return $this->penulis;
    }
    function judul()
    {
        return $this->judul;
    }
    function artikel1()
    {
        return $this->artikel1;
    }
    function artikel2()
    {
        return $this->artikel2;
    }
    function gambar()
    {
        $gambar = fopen('gambar/gambar.png', 'r');
        return fread($gambar, filesize("gambar/gambar.png"));
        fclose($gambar);
    }
}

$blog = new Blog();
?>
