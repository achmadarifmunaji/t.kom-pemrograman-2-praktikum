<?php 
require_once 'class/class.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prak06-22103001009-Muhammad Arlianto</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="blog">
        <div class="nameBlog">
            <h1><?php echo $blog->nameBlog(); ?></h1>
        </div>
    </div>
    <div class="gambar">
        <div class="gambar1">
            <h1><?php echo var_dump($blog->gambar()); ?></h1>
        </div>
    </div>
    <div class="judul">
    <h1><?php echo $blog->judul(); ?></h1>
    <span><?php echo $blog->tanggal().", ".$blog->bulan().", ".$blog->tahun().", ".$blog->penulis(); ?></span>
    </div>
    <div class="artikel">
        <div class="artikel1">
            <p><?php echo $blog->artikel1(); ?></p>
        </div>
        <div class="artikel2">
            <p><?php echo $blog->artikel2(); ?></p>
        </div>
    </div>
    
</body>
</html>