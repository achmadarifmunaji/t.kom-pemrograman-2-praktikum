<?php

class Blog {
 public $namaBlog="SifatManusia.co.id";
 public $gambar="images/images.jpg";
 public $judulArtikel="Mengenal Sifat Egois";  
 public $tanggal=10 ;
 public $bulan=" Juni ";
 public $tahun=2023;
 public $penulis="Muhammad Iqbal ";

 public function isiArtikel1(){
    return "Egois adalah kecenderungan untuk memprioritaskan 
    keinginan dan kebutuhan sendiri di atas kebutuhan 
    dan keinginan orang lain. Seseorang dengan sifat ini 
    kerap bertindak berlebihan dengan caranya, semata-mata untuk 
    menguntungkan diri sendiri, meski harus merugikan orang lain.
    <br>
    Sifat egois ini sendiri berasal dari 
    paham egoisme yang dikenalkan di dalam 
    dunia filsafat. Menurut paham tersebut, 
    egoisme adalah pandangan bahwa seseorang bertindak 
    dan harus bertindak untuk kepentingan dan keinginannya sendiri.";
 }
 public function isiArtikel2(){
    return "Sifat egois itu sendiri sebenanya 
    dimiliki oleh setiap orang. Hanya saja, 
    beberapa orang mungkin memiliki tingkat egoisme 
    yang tinggi dan berlebihan, yang justru dapat merugikan orang lain.
 <br>
    Pada tahap tertentu, keegoisan yang dilakukan 
    masih dianggap normal. Ini biasanya dilakukan 
    sebagai bentuk self love atau cara mencintai diri sendiri, 
    seperti memenuhi kebutuhan makanannya sendiri sebelum 
    memberikan kepada orang lain. Ini juga bisa ditunjukkan 
    dengan menolong dirinya sendiri terlebih dahulu saat 
    terluka sebelum membantu orang lainnya.";
 }
}