<?php require_once "class/class.php";
	    $blog1 = new Blog();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel = "stylesheet" href = "css/style-output.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
</head>
<body>
<div class="semua">
  <div class="nama">
    <h1>
         <?php echo $blog1->namaBlog;?>
    </h1> 
  </div> 

  <div class="gambar">
      <img src="<?php echo $blog1->gambar;?>">
  </div> 

  <div class="judul">
    <h1 class="tk">
         <?php echo $blog1->judulArtikel;?>
    </h1> 
    <p>
    <?php echo $blog1->penulis;
          echo $blog1->tanggal;
          echo $blog1->bulan;
          echo $blog1->tahun;?>
    </p>
  </div> 
  <div class="isi1">
    <p>
         <?php echo $blog1->isiArtikel1();?>
    </p> 
  </div> 

  <div class="isi2">
    <p>
    <?php echo $blog1->isiArtikel2();?>
    </p> 
  </div> 
</div>
</body>
</html>