<?php
class Blog{
    public $nama = "Retawrite.com";
    public $image = "granola.webp";
    public $judul = "Manfaat Granola Yang Baik Untuk Kesehatan";
    public $tanggal = 9;
    public $bulan = "Juni";
    public $tahun = 2023;
    public $penulis = "by <em>Raita Rahmatina</em>";
}

function isiArtikel(){
    return "<b>Granola</b> adalah salah satu olahan makanan yang terbuat dari gandum, kacang-kacangan, dan buah kering. 
    Biasanya granola juga ditambahkan dengan minyak, madu, atau pemanis alami. Granola memiliki tekstur yang renyah
    karena diproses dengan cara dipanggang. Belakangan ini granola kian digemari untuk dikonsumi saat sarapan.Pasalnya granola";  
}
function isiArtikel2(){
    return "cenderung praktis dan mudah diolah menjadi berbagai menu makanan.Untuk kamu yang sering tidak punya banyak waktu untuk sarapan bisa coba mengonsumsi granola di pagi hari.
    Cukup tambahkan susu atau yogurt kamu sudah dapat menikmati sarapan sehat dan menyenangkan.Yuk, cari tahu dulu 
    manfaat granola yang baik untuk kesehatan di bawah ini <b><a href='#'>click here</a></b>.";
}
function copyRight(){
    return "<a herf='#'>&copy CopyRight 2023 Retawrite</a>";
}
