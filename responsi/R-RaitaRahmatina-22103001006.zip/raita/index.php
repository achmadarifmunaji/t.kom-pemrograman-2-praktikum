<?php
require_once "blog.php";
$responsi = new blog();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsi</title>
    <link rel="stylesheet" href="desain/style.css">
</head>
<body>
    <div class="a">
    <h1>
        <?php
        echo $responsi->nama;
        ?>
    </h1>
    </div>
    <div class = "b">
        <img src="<?php echo $responsi->image;?>">

    <div class="c">
    <h1>
        <?php
        echo $responsi->judul;
        ?>
    </h1>
    <div class="d">
    <p>
        <?php
        echo $responsi->tanggal ." ". $responsi->bulan ." ". $responsi->tahun ." ". $responsi->penulis;
        ?>
    </p>  
    </div>
    <div class="e">
        <p>
            <?php
            echo isiArtikel();
            ?>
        </p>
    </div>
    <div class="f">
        <p>
            <?php
            echo isiArtikel2();
            ?>
        </p>
    </div>
    <div class="g">
        <p>
            <?php
            echo copyRight();
            ?>
        </p>
    </div>
</body>
</html>