<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css" >
</head>
<body>
<div>
  <ul>
    <h1 class ="t">
        <?php require_once "Blog/Blog.php";
	    $titel1 = new Blog();
        echo $titel1->title;?>
    </h1>    
    <p class="p">
        <?php $paragrap1 = new Blog();
        echo $paragrap1->paragraph1();?>
    </p>
    <a class = "w" href="/">
            <?php $a = new Blog();
            echo $a->link();?>
    </a>
  </ul>
</div>
<ol>
    <h1 class="c">
        <?php $titel2 = new Blog();
        echo $titel2->title2; ?>
    </h1>
        <?php $tg = new Blog();
        echo $tg->date; ?>
    <a href="/">
        <?php $lk = new Blog();
        echo $lk->time(); ?>
    </a>
    <p>
        <?php $jk = new Blog();
        echo $jk->information1(); ?>
    </p>
    <p>
        <?php $jk = new Blog();
        echo $jk->information2(); 
        $jk = new Blog();
        echo $jk->besar(); 
        $jk = new Blog();
        echo $jk->info(); ?>
    </p>
    <p>
        <?php $jk = new Blog();
        echo $jk->info3(); ?>
    </p>
</ol>
</body>
</html>

