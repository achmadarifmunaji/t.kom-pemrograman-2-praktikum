<?php

interface Car {
  public $name;
  public function __construct($name) {
    $this->name = $name;
  }
  public function intro($price);
}

class Audi implements Car{

  public function intro($price){
    $str =  "Choose Car quality! I'm an  $this->name ! and my price is  {$price} " ;
    return $str;
  }
}

class Volvo implements Car {

  public function intro($price){
    $str =  "Choose Car quality! I'm an  $this->name ! and my price is  {$price} " ;
    return $str;
  }
}

class Citroen implements Car {

  public function intro($price){
    $str =  "Choose Car quality! I'm an  $this->name ! and my price is  {$price} " ;
    return $str;
  }
}

class CetakInfo{
    public $daftarCar = array();
    public function tambahkanCar(Car $Car){
        $this->daftarCar[] = $Car;
    }

    Public function cetak(){
        $str = "List Car :  <br/>";
        foreach ($this->daftarCar as $p){
            $str .= "- {$p->intro()} <br/>";
        } 
        return $str;
    }
}

$car1 = new Audi("Audi As");
$car2 = new Valvo("volvo 2023");
$car3 = new Citroen("Citroens C3 2016");
$cetakCar = new Car();
$cetakCar->tambahkanCar($car1);
$cetakCar->tambahkanCar($car2);
$cetakCar->tambahkanCar($car3);
echo $cetakCar->cetak();