<?php

abstract class Car {
  public $name;
  public function __construct($name) {
    $this->name = $name;
  }
  abstract public function intro($price);

}

class Audi extends Car {

  public function intro($price){
    $str =  "Choose Car quality! I'm an  $this->name ! and my price is  {$price} " ;
    return $str;
  }
}

class Volvo extends Car {

  public function intro($price){
    $str =  "Choose Car quality! I'm an  $this->name ! and my price is  {$price} " ;
    return $str;
  }
}

class Citroen extends Car {

  public function intro($price){
    $str =  "Choose Car quality! I'm an  $this->name ! and my price is  {$price} " ;
    return $str;
  }
}

$car1 = new Audi("Audi As");
echo $car1->intro("Rp. 678.000");
echo "<br/>";

$car2 = new Volvo("volvo 2023");
echo $car2->intro("Rp. 995.000");
echo "<br/>";

$car3 = new Citroen("Citroens C3 2016");
echo $car3->intro("Rp. 202.000");
echo "<br/>";
