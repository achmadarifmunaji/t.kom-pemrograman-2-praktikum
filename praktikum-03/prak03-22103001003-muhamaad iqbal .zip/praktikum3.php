<?php
class Fruit {
  protected $name;
  protected $color;

  function __construct($name, $color){
    $this->name = $name;
    $this->color = $color;
  }
  function get_name() {
    return $this->name;
  }
  function get_color() {
    return $this->color;
  }
}
class Orange extends Fruit {
    private $teste; 
    public static $height = 4.12;
    public function nameFruit(){
      return "Orange" . self::$height;
    }
    function __construct($name, $color, $teste = "bitter"){
      parent:: __construct($name, $color);
      $this->teste = $teste;
    }
    function itsTeste(){
      return "$this->name colored 
      $this->color have teste $this->teste";
    }
    function getTaste(){
      return "$this->teste";
    }
    function setTaste($teste){
      $this->teste = $teste;
    }
}
$fruit = new Fruit("Orange", "Oren");
$orange = new Orange("Orange", "Oren", "bitter");
$orange->setTaste("sweet");

//var_dump($fruit);
echo $fruit->get_name();
echo "<br>";
echo $fruit->get_color();
echo "<br>";
echo $orange->itsTeste();
echo "<br>";
echo $orange->getTaste();
echo "<br>";
echo Orange::$height;
echo "<br/>";


// tugas kedua 
class Person {
  const SPECIES = "Homo Sapiens";
  public $name;
  public $age;
  public $occupation;

  function __construct($name = 0, $age = 0, $occupation = 0)
  {
    $this->name = $name;
    $this->age = $age;
    $this->occupation = $occupation;
  }
  function introduce(){
      return "Hello, my name is {$this->name}";
  }

  function  describe_job(){
      return "I am currently working as a {$this->occupation}";
  }

  function greet_extraterrestrials(){
      return "Welcome to Planet Earth ".self::SPECIES;
  }
}

$Persons = new Person( "dea alfrizal",22,"programmer");

echo $Persons->introduce();
echo "<br/>";
echo $Persons->describe_job();
echo "<br/>";
echo $Persons->greet_extraterrestrials();